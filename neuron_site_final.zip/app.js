// Placeholder for future logic (auth, routing)
console.log("Neuron landing ready.");